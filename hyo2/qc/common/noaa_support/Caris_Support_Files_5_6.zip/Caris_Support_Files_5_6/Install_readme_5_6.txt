Version 5.6

Unzip the Caris support files into the C:\CARIS directory. This should create a new folder named
C:\CARIS\CARIS_Support_Files_5_6 that contains the support files and folders.

The batch file is named Caris_Support_Files_5_6.bat. Retain the default file paths and registry entries in the batch
file or reconfigure as desired. Execute the batch file logged in as administrator with all other users logged off the system.

The batch file (Caris_Support_Files_5_6.bat) will copy version 5.6 of the NOAA CARIS support files from the
C:\CARIS\CARIS_Support_Files_5_6 folder to the correct CARIS folders on your machine. The process will only work if
you have the support files stored in a C:\CARIS\CARIS_Support_Files_5_6 folder.

The support files should be copied as below:

Notebook 3.1:
<System_Files> ----------------------------->C-CARIS-Notebook-31-System
<Profiles_Pools_ProductInfo> --------------->C-CARIS-Notebook-31-System-S57Config-System
<Symbolization>----------------------------->C-CARIS-Notebook-31-System-S57Config-Symbolization-Lookup

Bathy DataBASE 4.1:
<System_Files> ----------------------------->C-Program Files-CARIS-BDB-4.1-System
<Profiles_Pools> --------------------------->C-Program Files-CARIS-BDB-4.1-System-S57Config-System
<ProductInfo> ------------------------------>C-Program Files-CARIS-BDB-4.1-System-S57Config-System
<Symbolization>----------------------------->C-Program Files-CARIS-BDB-4.1-System-S57Config-Symbolization-Lookup
<Rule_Files>-------------------------------->C-Program Files-CARIS-BDB-4.1-system-RuleFiles

BASE Editor 4.2:
<System_Files> ----------------------------->C-Program Files-CARIS-BASE Editor-4.2-system
<Profiles_Pools> --------------------------->C-Program Files-CARIS-BASE Editor-4.2-system-S57Config-system
<ProductInfo> ------------------------------>C-Program Files-CARIS-BASE Editor-4.2-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-BASE Editor-4.2-system-S57Config-symbolization-lookup
<Rule_Files>-------------------------------->C-Program Files-CARIS-BASE Editor-4.2-modules-BASE Editor-support-Rules

BASE Editor 4.3:
<System_Files> ----------------------------->C-Program Files-CARIS-BASE Editor-4.3-system
<Profiles_Pools> --------------------------->C-Program Files-CARIS-BASE Editor-4.3-system-S57Config-system
<ProductInfo> ------------------------------>C-Program Files-CARIS-BASE Editor-4.3-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-BASE Editor-4.3-system-S57Config-symbolization-lookup
<Rule_Files>-------------------------------->C-Program Files-CARIS-BASE Editor-4.3-modules-Basic Charting Tools-support-Rules

BASE Editor 4.4:
<System_Files> ----------------------------->C-Program Files-CARIS-BASE Editor-4.4-system
<Profiles_Pools> --------------------------->C-Program Files-CARIS-BASE Editor-4.4-system-S57Config-system
<ProductInfo> ------------------------------>C-Program Files-CARIS-BASE Editor-4.4-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-BASE Editor-4.4-system-S57Config-symbolization-lookup
<Rule_Files>-------------------------------->C-Program Files-CARIS-BASE Editor-4.4-modules-Basic Charting Tools-support-Rules

Plot Composer 5.3:
<System_Files> ----------------------------->C-Program Files-CARIS-PlotComposer-5.3-System
<Profiles_Pools_ProductInfo> --------------->C-Program Files-CARIS-PlotComposer-5.3-System-S57Config-System
<Symbolization>----------------------------->C-Program Files-CARIS-PlotComposer-5.3-System-S57Config-Symbolization-Lookup
<PCEConfig>--------------------------------->C-Program Files-CARIS-PlotComposer-5.3-System-PCEConfig
<Templates>--------------------------------->C-Program Files-CARIS-PlotComposer-5.3-System-Templates_53

Easyview 4.0:
<System_Files> ----------------------------->C-Program Files-CARIS-EasyView-4.0-System
<Profiles_Pools_ProductInfo>---------------->C-Program Files-CARIS-EasyView-4.0-System-S57Config-System
<Symbolization>----------------------------->C-Program Files-CARIS-EasyView-4.0-System-S57Config-Symbolization-Lookup

HIPS & SIPS 7.1
<System_Files> ----------------------------->C-CARIS-HIPS(x64)-71-System
<Profiles_Pools>---------------------------->C-CARIS-HIPS(x64)-71-System-S57Config-System
<ProductInfo>------------------------------->C-CARIS-HIPS(x64)-71-System-S57Config-System
<Symbolization>----------------------------->C-CARIS-HIPS(x64)-71-System-S57Config-Symbolization-Lookup

HIPS & SIPS 9.1
<System_Files> ----------------------------->C-Program Files-CARIS-HIPS-9.1-System
<Profiles_Pools>---------------------------->C-Program Files-CARIS-HIPS-9.1-System-S57Config-System
<ProductInfo>------------------------------->C-Program Files-CARIS-HIPS-9.1-System-S57Config-System
<Symbolization>----------------------------->C-Program Files-CARIS-HIPS-9.1-System-S57Config-Symbolization-Lookup

HIPS & SIPS 10.2
<System_Files> ----------------------------->C-Program Files-CARIS-HIPS and SIPS-10.2-System
<Profiles_Pools>---------------------------->C-Program Files-CARIS-HIPS and SIPS-10.2-System-S57Config-System
<ProductInfo>------------------------------->C-Program Files-CARIS-HIPS and SIPS-10.2-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-HIPS and SIPS-10.2-System-S57Config-Symbolization-Lookup

HIPS & SIPS 10.3
<System_Files> ----------------------------->C-Program Files-CARIS-HIPS and SIPS-10.3-System
<Profiles_Pools>---------------------------->C-Program Files-CARIS-HIPS and SIPS-10.3-System-S57Config-System
<ProductInfo>------------------------------->C-Program Files-CARIS-HIPS and SIPS-10.3-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-HIPS and SIPS-10.3-System-S57Config-Symbolization-Lookup

S57 Composer
<System_Files> ----------------------------->C-CARIS-S-57 Composer-30-System
<Profiles_Pools>---------------------------->C-CARIS-S-57 Composer-30-System-S57Config-System
<ProductInfo>------------------------------->C-CARIS-S-57 Composer-30-System-ProductInfoFiles
<Symbolization>----------------------------->C-CARIS-S-57 Composer-30-System-S57Config-Symbolization-Lookup

      - File Versions -

atr_lut.txt			= Version 5.6
obj_lut.txt			= Version 5.6
NOAA_cataloguecontrol.xml	= Version 5.6
NOAA Profile Version 5.6.xml	= Version 5.6
NOAAunifiedPool.xml		= Version 5.6
s57productinfo_NOAA.xml		= Version 5.6
psymrefs.dic			= Version 5.6
psymreft.dic			= Version 5.6
HIPS2NOAAHOB.xml        	= Version 5.6

IH_BorderStyles.bsd
NOAA_Plot_Template_ARCH-D_Landscape.plt
NOAA_Plot_Template_ARCH-D_Portrait.plt